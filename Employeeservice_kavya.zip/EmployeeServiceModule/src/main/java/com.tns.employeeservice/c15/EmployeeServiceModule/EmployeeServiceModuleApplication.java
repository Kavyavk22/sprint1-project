package com.priya.EmployeeServiceModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeServiceModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeServiceModuleApplication.class, args);
	}

}
